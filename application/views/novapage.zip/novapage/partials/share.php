<div class="social-share">
	Share :
	<script language="javascript">
	document.write("<a href='http://www.facebook.com/share.php?u=" + document.URL + " ' target='_blank' class='custom-soc icon-text'><i class='fa fa-facebook' aria-hidden='true'></i></a> "+
	"<a href='http://twitter.com/home/?status=" + document.URL + "' target='_blank' ><i class='fa fa-twitter' aria-hidden='true'></i></a> ");
	</script>
</div>