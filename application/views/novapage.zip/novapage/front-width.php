<div class="container top-mt-120">
		<div class="row">
            <div class="col-lg-12"> 
                <?php echo $contents; ?> 
            </div> 
    </div>
</div>